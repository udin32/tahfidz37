# Tahfidz Twenty One
Dipublikasikan di https://tahfidz.smpn21purworejo.sch.id/

Aplikasi ini ditujukan untuk membantu siswa SMPN 21 Purworejo dalam menghafalkan dan memahami surat-surat pendek dalam Quran. Dilengkapi audio dan dapat diberi tanda jika sudah berhasil menghafalkan.

Aplikasi ini ditenagai oleh Perpustakaan Twenty One.

